import React, { useRef, useState } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { HowItWorks } from './components/HowItWorks';
import { Rewards } from './components/Rewards';
import { Verification } from './components/Verification';
import { Footer } from './components/Footer';

export default function App() {
  const verificationRef = useRef<HTMLDivElement>(null);
  const [triggerVerification, setTriggerVerification] = useState(false);

  const scrollToVerification = () => {
    setTriggerVerification(true);
    verificationRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
  };

  return (
    <div className="min-h-screen bg-gaming-bg text-white overflow-x-hidden selection:bg-gaming-primary selection:text-gaming-bg">
      {/* Background Gradient Effect */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-gaming-secondary/20 rounded-full blur-[120px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-gaming-primary/10 rounded-full blur-[120px]" />
      </div>

      <div className="relative z-10">
        <Header />
        
        <main className="flex flex-col gap-16 md:gap-24 pb-20">
          <Hero onDownloadClick={scrollToVerification} />
          <HowItWorks />
          <Rewards />
          
          <div ref={verificationRef} className="scroll-mt-20">
            <Verification isTriggered={triggerVerification} />
          </div>
        </main>

        <Footer />
      </div>
    </div>
  );
}