import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="w-full py-8 mt-auto border-t border-white/5 bg-black/40">
      <div className="container mx-auto px-4 text-center">
        <p className="text-xs text-gray-600 max-w-2xl mx-auto leading-relaxed mb-4">
          This promotion is available for users in the United States only. 
          Trademarks and logos belong to their respective owners. 
          This site is not affiliated with Google, Amazon, Steam, or PlayStation.
          Rewards are subject to availability.
        </p>
        <p className="text-[10px] text-gray-700">
          © {new Date().getFullYear()} MISTPLAY Rewards Program. All rights reserved.
        </p>
      </div>
    </footer>
  );
};