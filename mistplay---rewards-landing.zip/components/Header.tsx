import React from 'react';
import { Gamepad2 } from 'lucide-react';

export const Header: React.FC = () => {
  return (
    <header className="sticky top-0 z-50 w-full backdrop-blur-xl bg-gaming-bg/80 border-b border-white/5">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 md:w-10 md:h-10 bg-gradient-to-br from-gaming-primary to-emerald-600 rounded-lg flex items-center justify-center shadow-[0_0_15px_rgba(0,255,157,0.3)]">
            <Gamepad2 className="text-gaming-bg w-5 h-5 md:w-6 md:h-6" />
          </div>
          <div className="flex flex-col">
            <h1 className="font-display text-xl md:text-2xl tracking-wider text-white">
              MISTPLAY
            </h1>
            <span className="text-[10px] md:text-xs text-gray-400 font-medium tracking-wide hidden sm:block">
              PLAY GAMES. EARN GIFT CARDS.
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2 bg-white/5 px-3 py-1.5 rounded-full border border-white/10">
          <span className="text-xl">🇺🇸</span>
          <span className="text-xs font-semibold text-gray-300">USA Only</span>
        </div>
      </div>
    </header>
  );
};