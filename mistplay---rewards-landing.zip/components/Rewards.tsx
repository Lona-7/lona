import React from 'react';
import { ShoppingCart, CreditCard, Gamepad2, Monitor } from 'lucide-react';

export const Rewards: React.FC = () => {
  const rewards = [
    { name: "Amazon", icon: <ShoppingCart className="w-6 h-6" />, color: "from-orange-500 to-yellow-500" },
    { name: "Google Play", icon: <CreditCard className="w-6 h-6" />, color: "from-blue-500 to-green-500" },
    { name: "Steam", icon: <Monitor className="w-6 h-6" />, color: "from-blue-700 to-blue-900" },
    { name: "PlayStation", icon: <Gamepad2 className="w-6 h-6" />, color: "from-indigo-600 to-blue-600" },
  ];

  return (
    <section className="container mx-auto px-4">
      <div className="relative rounded-3xl bg-gradient-to-r from-gray-900 to-gaming-card p-8 md:p-12 border border-white/10 overflow-hidden glow-box">
        {/* Decorative elements */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-gaming-primary/10 blur-[80px] rounded-full" />
        
        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="text-center md:text-left">
            <h3 className="text-2xl md:text-3xl font-display font-bold mb-2">
              Choose Your Reward
            </h3>
            <p className="text-gray-400">
              Redeem points for real gift cards instantly.
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 w-full md:w-auto">
            {rewards.map((reward, idx) => (
              <div key={idx} className="flex flex-col items-center gap-3">
                <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${reward.color} flex items-center justify-center text-white shadow-lg transform hover:scale-110 transition-transform duration-200`}>
                  {reward.icon}
                </div>
                <span className="text-xs font-semibold text-gray-300">{reward.name}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};