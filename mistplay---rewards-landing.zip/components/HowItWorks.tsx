import React from 'react';
import { Download, Gamepad, Gift } from 'lucide-react';

export const HowItWorks: React.FC = () => {
  const steps = [
    {
      icon: <Download className="w-8 h-8 text-gaming-accent" />,
      title: "Download App",
      desc: "Get the official app for free on iOS or Android devices."
    },
    {
      icon: <Gamepad className="w-8 h-8 text-gaming-primary" />,
      title: "Play Games",
      desc: "Choose from a huge library of games and start playing."
    },
    {
      icon: <Gift className="w-8 h-8 text-gaming-secondary" />,
      title: "Earn Rewards",
      desc: "Collect units as you play and redeem them for gift cards."
    }
  ];

  return (
    <section className="container mx-auto px-4">
      <div className="text-center mb-12">
        <h3 className="text-3xl font-display font-bold mb-4">How It Works</h3>
        <p className="text-gray-400">Start earning in 3 simple steps</p>
      </div>

      <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
        {steps.map((step, idx) => (
          <div key={idx} className="relative group p-6 rounded-2xl bg-gaming-card border border-white/5 hover:border-gaming-primary/50 transition-all duration-300">
            {/* Step Number Background */}
            <div className="absolute top-2 right-4 text-6xl font-display font-bold text-white/5 group-hover:text-gaming-primary/10 transition-colors select-none">
              {idx + 1}
            </div>
            
            <div className="relative z-10 flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-2xl bg-white/5 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg">
                {step.icon}
              </div>
              <h4 className="text-xl font-bold mb-2 text-white group-hover:text-gaming-primary transition-colors">
                {step.title}
              </h4>
              <p className="text-gray-400 text-sm leading-relaxed">
                {step.desc}
              </p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};