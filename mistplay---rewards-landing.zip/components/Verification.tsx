import React, { useEffect, useState } from 'react';
import { ShieldCheck, Lock, Loader2, CheckCircle2 } from 'lucide-react';

interface VerificationProps {
  isTriggered: boolean;
}

export const Verification: React.FC<VerificationProps> = ({ isTriggered }) => {
  const [progress, setProgress] = useState(0);
  const [status, setStatus] = useState<'idle' | 'verifying' | 'locked'>('idle');

  useEffect(() => {
    if (isTriggered && status === 'idle') {
      setStatus('verifying');
      let currentProgress = 0;
      
      const interval = setInterval(() => {
        // Fast at first, slower at the end
        const increment = currentProgress < 50 ? 2 : currentProgress < 70 ? 0.5 : 0.1;
        currentProgress += increment;

        if (currentProgress >= 75) {
          currentProgress = 75;
          clearInterval(interval);
          setStatus('locked');
        }
        setProgress(currentProgress);
      }, 50);

      return () => clearInterval(interval);
    }
  }, [isTriggered, status]);

  const handleUnlockClick = () => {
    // This is where you would attach your Smartlink / CPA offer logic
    // Example: window.location.href = "YOUR_SMARTLINK_URL";
    alert("This button should redirect to your CPA offer or Smartlink.");
  };

  if (!isTriggered) return null;

  return (
    <section className="container mx-auto px-4 max-w-2xl">
      <div className="bg-gaming-card border border-white/10 rounded-2xl p-6 md:p-8 shadow-[0_0_40px_rgba(0,0,0,0.5)]">
        <div className="flex items-center justify-between mb-6 border-b border-white/5 pb-4">
          <div className="flex items-center gap-3">
            {status === 'locked' ? (
              <ShieldCheck className="w-6 h-6 text-yellow-500 animate-pulse" />
            ) : (
              <Loader2 className="w-6 h-6 text-gaming-primary animate-spin" />
            )}
            <span className="font-mono text-sm text-gray-400">
              SYSTEM_STATUS: {status === 'verifying' ? 'CHECKING_ELIGIBILITY' : 'ACTION_REQUIRED'}
            </span>
          </div>
          <div className="text-xs text-gray-500 font-mono">ID: 8392-US</div>
        </div>

        <div className="space-y-6">
          <div className="text-center">
            <h3 className="text-2xl font-bold mb-2">
              {status === 'verifying' ? 'Verifying User...' : 'Verification Required'}
            </h3>
            <p className="text-gray-400 text-sm">
              {status === 'verifying' 
                ? 'Please wait while we check for available slots in your region.'
                : 'We have reserved your spot! Complete one quick step to unlock your download.'}
            </p>
          </div>

          {/* Progress Bar */}
          <div className="relative w-full h-4 bg-gray-800 rounded-full overflow-hidden">
            <div 
              className={`absolute top-0 left-0 h-full transition-all duration-200 ease-out ${
                status === 'locked' ? 'bg-yellow-500' : 'bg-gaming-primary'
              }`}
              style={{ width: `${progress}%` }}
            />
            {/* Striped animation for progress bar */}
            <div className="absolute inset-0 w-full h-full bg-[linear-gradient(45deg,rgba(255,255,255,0.1)_25%,transparent_25%,transparent_50%,rgba(255,255,255,0.1)_50%,rgba(255,255,255,0.1)_75%,transparent_75%,transparent)] bg-[length:1rem_1rem] animate-[spin_1s_linear_infinite]" />
          </div>
          
          <div className="flex justify-between text-xs font-mono text-gray-500">
            <span>Progress: {Math.floor(progress)}%</span>
            {status === 'locked' && <span className="text-yellow-500">HALTED</span>}
          </div>

          {/* Locked State Action */}
          <div className={`transition-all duration-500 ${status === 'locked' ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4 pointer-events-none'}`}>
             <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-4 mb-6 flex items-start gap-3">
                <Lock className="w-5 h-5 text-yellow-500 shrink-0 mt-0.5" />
                <div className="text-sm text-gray-300">
                  <strong className="text-yellow-500 block mb-1">Automatic Verification Failed</strong>
                  To prevent bot abuse, please manually verify you are a human from the USA to continue.
                </div>
             </div>

             <button
               onClick={handleUnlockClick}
               className="w-full bg-gradient-to-r from-yellow-500 to-orange-600 hover:from-yellow-400 hover:to-orange-500 text-white font-bold py-4 rounded-xl shadow-[0_0_20px_rgba(234,179,8,0.3)] animate-pulse hover:animate-none transform hover:scale-[1.02] transition-all"
             >
               UNLOCK & CONTINUE
             </button>
          </div>
        </div>
      </div>
    </section>
  );
};