import React from 'react';
import { Smartphone, Apple } from 'lucide-react';

interface HeroProps {
  onDownloadClick: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onDownloadClick }) => {
  return (
    <section className="relative pt-12 md:pt-20 px-4">
      <div className="container mx-auto max-w-4xl text-center">
        
        {/* Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gaming-secondary/20 border border-gaming-secondary/40 text-gaming-secondary text-sm font-semibold mb-8 animate-pulse-slow">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-gaming-secondary opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-gaming-secondary"></span>
          </span>
          Top Rated Reward App 2024
        </div>

        <h2 className="text-4xl md:text-6xl lg:text-7xl font-display font-bold leading-tight mb-6">
          Play Free Games & <br/>
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-gaming-primary via-gaming-accent to-gaming-secondary glow-text">
            Earn Gift Cards
          </span> Instantly
        </h2>

        <p className="text-gray-400 text-lg md:text-xl mb-10 max-w-2xl mx-auto leading-relaxed">
          Join the community trusted by millions of gamers in the USA. 
          Discover new games, level up, and redeem your rewards today.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 w-full max-w-md mx-auto sm:max-w-none">
          <button 
            onClick={onDownloadClick}
            className="group relative w-full sm:w-auto flex items-center justify-center gap-3 bg-gradient-to-b from-emerald-500 to-emerald-700 hover:from-emerald-400 hover:to-emerald-600 text-white px-8 py-4 rounded-xl font-bold transition-all duration-300 transform hover:scale-105 shadow-[0_0_20px_rgba(16,185,129,0.4)] active:scale-95"
          >
            <Smartphone className="w-6 h-6 fill-current" />
            <div className="text-left">
              <div className="text-[10px] uppercase font-semibold opacity-80">Download for</div>
              <div className="text-lg leading-none">Android</div>
            </div>
            {/* Shine effect */}
            <div className="absolute inset-0 rounded-xl bg-gradient-to-r from-transparent via-white/20 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700 overflow-hidden" />
          </button>

          <button 
            onClick={onDownloadClick}
            className="group relative w-full sm:w-auto flex items-center justify-center gap-3 bg-gradient-to-b from-gray-700 to-gray-900 hover:from-gray-600 hover:to-gray-800 text-white px-8 py-4 rounded-xl font-bold transition-all duration-300 transform hover:scale-105 shadow-[0_0_20px_rgba(255,255,255,0.1)] border border-white/10 active:scale-95"
          >
            <Apple className="w-6 h-6 fill-current" />
            <div className="text-left">
              <div className="text-[10px] uppercase font-semibold opacity-80">Download for</div>
              <div className="text-lg leading-none">iPhone</div>
            </div>
          </button>
        </div>

        <div className="mt-8 flex items-center justify-center gap-2 text-sm text-gray-500">
          <div className="flex -space-x-2">
            {[1,2,3,4].map(i => (
              <div key={i} className="w-6 h-6 rounded-full border border-gaming-bg bg-gray-800 overflow-hidden">
                <img src={`https://picsum.photos/seed/user${i}/50/50`} alt="user" className="w-full h-full object-cover opacity-80" />
              </div>
            ))}
          </div>
          <span>10M+ Downloads in US</span>
        </div>
      </div>
    </section>
  );
};